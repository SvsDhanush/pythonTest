import requests

# Function to fetch webpage content
def fetch_webpage(url):
    response = requests.get(url)
    return response.text if response.status_code == 200 else f"Error fetching the webpage. status code: {response.status_code}"

url = 'https://jsonplaceholder.typicode.com/todos/1'
content = fetch_webpage(url)
print(content)
