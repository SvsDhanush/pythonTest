word_count = dict()

with open("input.txt", 'r') as file:
    data = file.read()

    words = data.split()
    
    # Create a new list to hold cleaned words
    cleaned_words = []

    for word in words:
        # Remove special characters and change to lowercase
        cleaned_word = ''.join(char for char in word if char.isalnum()).lower()
        if cleaned_word:  # Only add if cleaned_word is not empty
            cleaned_words.append(cleaned_word)
    
    for word in cleaned_words:
        if(word in word_count.keys()):
            word_count[word] += 1
        else:
            word_count[word] = 1

print(word_count)