from datetime import datetime

# Get the current date and time
now = datetime.now()

# Define the desired format
date_time_format = "%Y-%m-%d %H:%M:%S"

# Format the current date and time
formatted_date_time = now.strftime(date_time_format)

# Print the formatted date and time
print("Current date and time:", formatted_date_time)
