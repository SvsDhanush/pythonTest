def reverse_list(lst):
    
    for i in range(int(len(lst)/2)):
        
        temp = lst[i]
        lst[i] = lst[len(lst)-i-1]
        lst[len(lst)-i-1] = temp

ls = [1, 2, 3, 4, 5]
reverse_list(ls)
print("The reversed list: ", ls)