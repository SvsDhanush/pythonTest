def common_elements(l1, l2):
    
    elem = set()

    for i in l1:
        if i in l2:
            elem.add(i)

    return elem

list1 = [1, 2, 3, 4, 5]
list2 = [4, 5, 6, 7, 8]

numbers = common_elements(list1, list2)
print(f'The common elements are {numbers}')