numbers = range(1, 11)

odd_square_list = [x**2 for x in numbers if x%2 != 0]

print(odd_square_list)