def count_words(word_list):

    word_count = {}

    for word in word_list:

        if word in word_count:
            word_count[word] += 1
        else:
            word_count[word] = 1
            
    return word_count


input_list = ["apple", "banana", "apple", "orange", "banana", "apple"]
result = count_words(input_list)
print(result)
