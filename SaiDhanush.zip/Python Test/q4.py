from my_package import calculator

a = 10
b = 5

print(f"{a} + {b} = {calculator.add(a, b)}")
print(f"{a} - {b} = {calculator.subtract(a, b)}")
print(f"{a} * {b} = {calculator.multiply(a, b)}")
print(f"{a} / {b} = {calculator.divide(a, b)}")

# Example of division by zero
try:
    print(f"{a} / 0 = {calculator.divide(a, 0)}")
except ValueError as e:
    print(e)
